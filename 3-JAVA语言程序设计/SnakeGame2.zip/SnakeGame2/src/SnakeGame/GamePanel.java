package SnakeGame;

import javax.swing.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.List;
import java.util.Random;

/**
 * Created with IntelliJ IDEA.
 * User: Yang Wenjing
 * Date: 13-12-9
 * Time: 下午5:26
 * To change this template use File | Settings | File Templates.
 */
public class GamePanel extends JPanel{
    //蛇
    public Snake snake;
    //食物
    public Food food;
    //障碍物
    public Barrier barrier;

    public GamePanel(){
        snake = new Snake();
        List<Rectangle> slist = snake.getSnake(); //泛型，此List中只能存放 Rectangle类型的对象
        int x = 0;

		/*
		 * 画出初始状态的蛇
		 */
        for(Rectangle rt : slist){ //新的循环。 1.5版本后出的新内容
            //Rectangle rt = slist.get(i);
            rt.x = x;
            rt.y = 20;
            x += snake.WIDTH;
        }

        food = new Food();
        List<Rectangle> foodList = food.getFood();

        Random random = new Random();
        for(Rectangle food : foodList){
            food.x = random.nextInt(50)*10;//产生一个0-500的随机整数
            food.y = random.nextInt(42)*10;

        barrier = new Barrier();
        //ToDo:如何获取障碍物？
        List<Rectangle> barrierList = barrier.getBarrierList();  //获取障碍物
        for(Rectangle barrier : barrierList ){
            barrier.x = random.nextInt(50)*10;
            barrier.y = random.nextInt(50)*10;
        }
    }
    }

    public void paint(Graphics g){
        //画蛇
        List<Rectangle> snakeList = snake.getSnake();
        for(int i=0;i<snakeList.size()-1;i++){
            Rectangle rt = snakeList.get(i);
            g.fillRect(rt.x, rt.y, rt.width, rt.height);
        }
        Rectangle rt = snakeList.get(snakeList.size()-1);
        g.setColor(Color.BLACK);
        g.fillRect(rt.x, rt.y, rt.width, rt.height);
        //画食物
        List<Rectangle> foodList = food.getFood();
        g.setColor(Color.RED);
        for(Rectangle rt_f : foodList){
            g.drawRect(rt_f.x, rt_f.y, rt_f.width, rt_f.height);
            g.fillOval(rt_f.x, rt_f.y, rt_f.width, rt_f.height);//填充圆形
        }

        //画障碍物
        List<Rectangle> barrierList = barrier.getBarrierList();
        g.setColor(Color.BLUE);
        for(Rectangle rt_z : barrierList){
            g.fillRect(rt_z.x, rt_z.y, rt_z.width, rt_z.height);
        }
    }
}