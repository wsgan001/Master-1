package SnakeGame;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Created with IntelliJ IDEA.
 * User: Yang Wenjing
 * Date: 13-12-9
 * Time: 下午5:40
 * To change this template use File | Settings | File Templates.
 */
public class Food {
    private List foodList = new ArrayList();
    final int WIDTH = 10;
    final int HEIGTH = 10;
    public Food(){
        Rectangle rt = new Rectangle(WIDTH, HEIGTH);
        foodList.add(rt);
    }
    public void addNewFood()
    {
        Rectangle food = new Rectangle(WIDTH, HEIGTH);
        Random random = new Random();
        food.x = random.nextInt(50)*10+10;//产生一个0-500的随机整数
        food.y = random.nextInt(42)*10+10;
        foodList.add(food);
    }

    public List<Rectangle> getFood(){
        return foodList;
    }

}
