package SnakeGame;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
/**
 * Created with IntelliJ IDEA.
 * User: Yang Wenjing
 * Date: 13-12-9
 * Time: 下午5:35
 * To change this template use File | Settings | File Templates.
 */
public class Snake {
    private List slist = new ArrayList();
    final int WIDTH = 10;
    final int HEIGTH = 10;
    public Snake(){

        for(int i=0;i<4;i++){
            Rectangle rt = new Rectangle(WIDTH, HEIGTH);
            slist.add(rt);
        }
    }

    public List<Rectangle> getSnake(){
        return slist;
    }
}
