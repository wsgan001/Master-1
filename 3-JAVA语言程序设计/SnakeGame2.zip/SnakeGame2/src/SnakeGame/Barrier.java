package SnakeGame;
import java.awt.*;
import java.util.*;
import java.util.List;
/**
 * Created with IntelliJ IDEA.
 * User: Yang Wenjing
 * Date: 13-12-9
 * Time: 下午5:41
 * To change this template use File | Settings | File Templates.
 */

public class Barrier {
    private List barrierList = new ArrayList();
    final int WIDTH = 10;
    final int HEIGTH = 10;
    public Barrier(){
        for(int i = 0;i<8;i++){
            Rectangle rz = new Rectangle(WIDTH, HEIGTH);
            barrierList.add(rz);
        }
    }
    public List<Rectangle> getBarrierList(){
        return barrierList;
    }
}
