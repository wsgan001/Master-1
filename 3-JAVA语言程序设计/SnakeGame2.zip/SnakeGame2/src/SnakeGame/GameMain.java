package SnakeGame;

/**
 * Created with IntelliJ IDEA.
 * User: Yang Wenjing
 * Date: 13-12-9
 * Time: 下午5:53
 * To change this template use File | Settings | File Templates.
 */
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.Random;

import javax.swing.*;

public class GameMain {

    private JFrame frame;
    private GamePanel gamePanel;

    private int sign = 1;      //代表移动的方向 1：右。2：左.3:上。4：下
    private long time = 200;  //移动的时间间隔
    private boolean isLive = true;
    private int score = 0;      //初始分数
    private int currentValue = 100;  //进程条初始可见值
    private Random random = new Random();

    private JLabel scoresLabel;
    private JMenuBar menuBar;   //菜单栏
    private JProgressBar progressBar;  //进程条
    public GameMain(){
        frame = new JFrame("Game");
        progressBar = new JProgressBar();
        frame.setBounds(160, 120, 500, 420);
        progressBar.setValue(currentValue);  //血条初始值为100
        progressBar.setMinimum(0);  //血条最小值为0
        progressBar.setStringPainted(true);  //能在血条上显示文字的字符串
        gamePanel = new GamePanel();
        frame.add(gamePanel);
        scoresLabel = new JLabel(""+ score);
        frame.add(scoresLabel, BorderLayout.NORTH);
        frame.add(progressBar, BorderLayout.SOUTH);
        menuBar = new JMenuBar();
        JMenu jm1 = new JMenu("File");
        JMenuItem jmi1 = new JMenuItem("Start");
        JMenuItem jmi2 = new JMenuItem("Stop");
        JMenuItem jmi3 = new JMenuItem("Exit");

        JMenu jm3 = new JMenu("New");//需要包含子菜单的菜单
        jm1.add(jm3);

        jm1.add(jmi1);
        jm1.add(jmi2);
        jm1.addSeparator();//分割线
        jm1.add(jmi3);
        //New中的子菜单
        JMenuItem jmi5 = new JMenuItem("Class");
        JMenuItem jmi6 = new JMenuItem("File");
        JMenuItem jmi7 = new JMenuItem("Package");

        jm3.add(jmi5);
        jm3.add(jmi6);
        jm3.add(jmi7);

        JMenu jm2 = new JMenu("Edit");
        menuBar.add(jm1);
        menuBar.add(jm2);

        frame.setJMenuBar(menuBar);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);//窗口大小不可调整
        frame.setVisible(true);

		/*
		 * 匿名类,根据方向键给sign赋值
		 */
        frame.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                int code = e.getKeyCode();
                if (sign != 3 && code == KeyEvent.VK_DOWN) {
                    sign = 4;
                } else if (sign != 4 && code == KeyEvent.VK_UP) {
                    sign = 3;
                } else if (sign != 2 && code == KeyEvent.VK_RIGHT) {
                    sign = 1;
                } else if (sign != 1 && code == KeyEvent.VK_LEFT) {
                    sign = 2;
                }

            }
        });

        //start按钮的监听
        jmi1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isLive = true;
                MyThread mt = new MyThread();
                mt.start();
            }
        });

        //stop按钮的监听
        jmi2.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                isLive = false;
            }
        });

    }
    /*
     * 蛇的move
     */
    public void move(){
        Snake snake = gamePanel.snake;
        List<Rectangle> slist = snake.getSnake();
        int x = slist.get(0).x;//蛇尾的x坐标
        int y = slist.get(0).y;

        //后一格=前一格
        for(int i=0;i<slist.size()-1;i++){
            Rectangle rt1 = slist.get(i);
            Rectangle rt2 = slist.get(i+1);
            rt1.x = rt2.x;
            rt1.y = rt2.y;
        }

        //根据方向的转变判断蛇头的做坐标变换
        switch(sign){
            case 1:
                Rectangle rt1 = slist.get(slist.size()-1);
                rt1.x += snake.WIDTH;
                break;
            case 2:
                Rectangle rt2 = slist.get(slist.size()-1);
                rt2.x -= snake.WIDTH;
                break;
            case 3:
                Rectangle rt3 = slist.get(slist.size()-1);
                rt3.y -= snake.HEIGTH;
                break;
            case 4:
                Rectangle rt4 = slist.get(slist.size()-1);
                rt4.y += snake.HEIGTH;
                break;
        }
        testMove(x,y);
        frame.repaint();
    }
    //继承系统的Thread类
    class MyThread extends Thread{

        //重写run()方法
        public void run(){
            while(isLive){
                try {
                    Thread.sleep(time);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                move();
            }
        }
    }
    //判断是否超出范围或者碰撞
    public void testMove(int x,int y){
        //是否超界
        Snake snake = gamePanel.snake;
        List<Rectangle> slist = snake.getSnake();
        Rectangle snakeHead = slist.get(slist.size() - 1);  //代表蛇头的方块
        //判断越界有问题
        if(snakeHead.y<=0||snakeHead.y>=440||snakeHead.x>=480||snakeHead.x<=0){
            isLive = false;
            JOptionPane.showMessageDialog(null,"sorry,you are lose!");
        }

        //判断是否与食物相撞
        Food food = gamePanel.food;
        List<Rectangle> flist = food.getFood();
        for(Rectangle frt : flist){
            if(snakeHead.intersects(frt)){//rt和frt是否相交,相交,则吃到了食物
                Rectangle newrt = new Rectangle(x,y,snake.WIDTH,snake.HEIGTH);
                slist.add(0,newrt);
                flist.remove(frt);
                gamePanel.food.addNewFood();
                score += 50;   //每吃到一个食物增加50分
                scoresLabel.setText("" + score);

				/*
				 * 根据分数调整蛇move的速度
				 */
                if(score > 800){
                    time = 50;   //速度越大    移动的时间间隔越小
                }else if(score > 600){
                    time = 75;
                }else if(score > 400){
                    time = 100;
                }else if(score > 200){
                    time = 150;
                }
                break;
            }
        }

        //判断是否与障碍物相撞
        Barrier barrier = gamePanel.barrier;
        List<Rectangle> barrierList = barrier.getBarrierList();
        for(Rectangle zrt : barrierList){
            if(snakeHead.intersects(zrt)){
                currentValue -= 25;  //每相撞一次,血条下降25%
                progressBar.setValue(currentValue);
            }
        }

        //血条为0时死亡
        if(currentValue==0){
            isLive = false;
            JOptionPane.showMessageDialog(null,"sorry,you lose!");
        }

        //判断是否与自身相撞
        for(int i=0;i<slist.size()-1;i++){
            if(snakeHead.intersects(slist.get(i))){//判断代表蛇头的方块是否与其他的方块有交集
                isLive = false;
            }
        }
    }

    public static void main(String[] args) {
        new GameMain();
    }

}

